# A2-HTML-Responsive-Website

HTML Website project Based on the video tutorial by Brad Traversy:

https://www.youtube.com/watch?v=Wm6CUkswsNw&feature=youtu.be

In this video Brad uses 'Atom' as his IDE, we will be using VS Code.

This repo has the starter folders and files for CSS, Images, and index.html

There are 11 branches that cover the design and css styling for the home page.
Each branch corresponds to the sequential changes that Brad makes in the video tutorial.
It is recommended that you watch the video several times and use the different branches to 
get a solid understanding of the html and css coding for each section of the home page.
